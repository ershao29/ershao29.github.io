# DAGMC-SDF Teaching Demo

An independent Python companion to Shriwise et al., M&C 2017. Read the [English paper summary](../../literature/notes/dagmc-sdf-particle-tracking.md) and [archived run report](output/run-report.md).

## Run

Core algorithms, experiments, and tests require only Python 3.9+ standard libraries. From the workspace root:

```bash
cd summary/demos/dagmc-sdf
python3 -m unittest -v
python3 demo.py --samples 5000 --histories 200
```

The default `output` directory is relative to the script. Running the demo overwrites matching output filenames. Use `--output` to choose another directory. Seeds are fixed by default; timings vary with load.

Optional plots require matplotlib:

```bash
python3 -m pip install -r requirements-plots.txt
python3 plot_results.py --output output
```

## Code and contracts

| File | Contents |
|---|---|
| [sdf_preconditioner.py](sdf_preconditioner.py) | Triangle nearest points, AABB BVH, directional intersections, grids, interpolation, prefilters, utilization, walks |
| [demo.py](demo.py) | Uniform-volume sampling, bounds, query benchmarks, random walks, nonconvex example |
| [test_algorithms.py](test_algorithms.py) | 16 tests with independent references, theory integrals, and paired-history consistency |
| [plot_results.py](plot_results.py) | Utilization, field, safe-ball, angular, and performance PNG/SVG figures |

The field is **positive inside**. `paper` uses the voxel diagonal; `rms` is the explanatory tighter Lipschitz bound from the notes, not the original paper algorithm.

```python
from sdf_preconditioner import Sphere, UniformGrid, Prefilter

volume = Sphere(10.0)
grid = UniformGrid.build(volume.bounds, 16, volume.inside_distance)
query = Prefilter(volume, grid, error_mode="paper")
inside = query.contains((0.0, 0.0, 0.0))
lower = query.safety_distance((0.2, 0.0, 0.0))
exact = query.safety_distance((0.2, 0.0, 0.0), require_exact=True)
# Direction must be unit length. None means no boundary before the event.
hit = query.next_event((0.0, 0.0, 0.0), (1.0, 0.0, 0.0), 0.5, mode="pair")
print(inside, lower, exact, hit, query.counts)
```

`DistanceAnswer.exact=False` identifies a conservative lower bound. Callers requiring the reference geometry distance must request `require_exact=True`. Supply a valid `node_error` for uncertain grid nodes; an empirical RMS error is not a certificate.

## Outputs

- [metrics.json](output/metrics.json): configuration, correctness checks, builds, and walks.
- [utilization.csv](output/utilization.csv): fixed/exponential-flight theory, independent samples, and field certificates.
- [benchmark.csv](output/benchmark.csv): timings and ray/triangle counts on the same reference geometry.
- [error-bounds.csv](output/error-bounds.csv): measured interpolation error versus bounds.
- [run-report.md](output/run-report.md) and [test-results.txt](output/test-results.txt): archived readable results.
- PNG/SVG pairs: utilization, safe-ball certificates, distance field, angular restrictions, mesh benchmarks.

![Utilization](output/utilization.png)

## Scope

The AABB hierarchy illustrates the paper's OBB-BVH idea. Generated triangle meshes are closed and consistently oriented. This program does not integrate MOAB, Cubit, DAGMC, or MCNP. Analytic spheres validate probability formulas; mesh fields and reference queries use the same triangle geometry.

Walks include exponential flights, isotropic scattering, absorbing outer boundaries, and a collision cap, without real nuclear data, energy changes, electron physics, or general multi-material tracking. `capped` histories remain in statistics and are not escapes.

Existing tests establish consistency for their finite cases; floating predicates and guards are educational. Archived small Python benchmarks reduced ray calls but did not improve total query time. The paper's transport speedups are separate historical evidence.
