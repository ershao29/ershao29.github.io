# SDF-Grid Ray Tracing Teaching Demo

An independent CPU companion to Hansson-Soderlund, Evans, and Akenine-Moller, JCGT 2022. Read the [English paper summary](../../literature/notes/ray-tracing-sdf-grids.md).

Requires Python 3.9+ standard libraries, with no GPU or third-party packages. From the workspace root:

```bash
cd summary/demos/sdf-ray-tracing
python3 -m unittest -v
python3 demo.py --grid 16 --size 192 --rays 1000
python3 demo.py --quantize --output output-quantized --grid 16 --size 112 --rays 500
```

Runs overwrite matching files in the selected output directory. Default output is script-relative; explicit `--output` is relative to the current directory. `--grid` is voxels per axis and must be a power of two at least 2; `--size` is image width/height; `--rays` controls benchmark rays.

## Outputs

| Files | Purpose |
|---|---|
| `analytic.png`, `tetra.png`, `smooth.png` | Three normal constructions on the same hit geometry |
| `comparison.png`, `comparison.svg` | Side-by-side shading |
| `cubic.svg` | Multiple roots with same-sign endpoints |
| `normal-continuity.svg` | Normal components along a sphere section |
| `benchmark.csv`, `metrics.json` | 17 traversal/solver combinations, counters, timings, shadows |
| `run-report.md` | Readable results |

Archived reports: [unquantized](output/run-report.md), [shared-node snorm8 quantization](output-quantized/run-report.md).

![Analytic, finite-difference, and continuous normals](output/comparison.png)

## Interfaces and semantics

[sdf_grid.py](sdf_grid.py) provides `trilinear`, `gradient`, optimized `cubic_coefficients`, `first_root`, `Grid.trace`, `Grid.normal`, and `Stats`. The coefficient polynomial is **-F**; field signs and geometric normals use F.

```python
from sdf_grid import Grid, scene_sdf, unit

grid = Grid(16, scene_sdf)
hit = grid.trace((2.5, 1.7, 3.8), unit((-2.5, -1.7, -3.8)),
                 traversal="SVS", solver="A")
print(hit)
```

`Hit.t` uses the caller's ray parameter and equals physical length only for a unit direction. Local voxel transformations preserve that parameter.

`any_hit=True` only answers Boolean occlusion on a finite segment. Its returned `Hit.t` may be a root-bracket endpoint and must not define a physical hit point or length. Pass the upper query bound through `far`.

## Implementation scope and validation

Includes trilinear intersections, optimized cubics, derivative partitioning, continuous dual-voxel normals, opaque-shadow early exits, software BVH, brick DDA, and octree traversal. M/NR add bracket/bisection protection. GST uses a dense global Lipschitz bound; ST uses a directional derivative bound. Shared nodes plus halo replace per-voxel GPU redundancy. Quantization uses shared snorm8 nodes.

There is no DXR/RTX, HLSL gather, original asset set, multibounce path tracer, BC4, or 2023 tight-box extension. CPU timing is educational and does not establish GPU rankings.

The 12 existing tests cover polynomial roots, repeated/degenerate roots, direct interpolation, finite-difference gradients, traversal agreement, corners/parallel rays, interior starts, anisotropic voxels, normal continuity, quantized shared faces, and clipped shadows. DDA+A on the same trilinear field is the benchmark reference. ST/GST have finite budgets and approximation thresholds; `exhausted` counts local/traversal exhaustion events rather than unique rays. Double precision and heuristic tolerances do not constitute a certified industrial geometry kernel.
